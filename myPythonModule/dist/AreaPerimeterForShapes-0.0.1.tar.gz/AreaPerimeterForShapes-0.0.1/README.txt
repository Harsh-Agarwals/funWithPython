This python module contains basic arithmetic functions for shapes like -
- Rectangle
- Circle
- Triangle

and arithmetic functions includes:
- perimeter
- area

* For rectangle, use function parameters as length and breadth
* For circle, use function parameters as radius
* For triangle, calculating function is of type **kwargs so,
    include parameters as either side as (side=x)
    or include parameters as base and height as (base=x, height=y)